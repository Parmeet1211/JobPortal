[
  {
    course: "BCA",
    university: "GNDU",
    fromyear: "2016",
    toyear: "2019",
    marks: "92",
  },
  {
    course: "+2",
    university: "PSEB",
    fromyear: "2012",
    toyear: "2013",
    marks: "98",
  },
];



[{"githib":"radha2012","facebook" : "radha@facebook","linkedIn":"radha2012ll"}]


[{"skillId" : "644ff119e09230bc43c4667e"},{"skillId" : "644ff135e09230bc43c46682"}]